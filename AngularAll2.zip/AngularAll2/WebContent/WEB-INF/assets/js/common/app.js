(function() {
	'use strict';
	angular.module('aaApp', [ 'aaApp.ang1','ui.router']);
	angular.module('aaApp.ang1', ['ui.router']);
})();

